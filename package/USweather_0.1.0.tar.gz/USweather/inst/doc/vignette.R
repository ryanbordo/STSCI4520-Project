## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  warning = FALSE,
  message = FALSE
)

## ----setup--------------------------------------------------------------------
library(USweather)

## -----------------------------------------------------------------------------
# map of the average temperature of stations in March 2024 vs the interpolated data map
graphics.off()
non_contig <- c("AK", "HI", "NL", "PE", "NS", "NB", "QC", "ON", "MB", "SK", "AB", "BC", "YT", "NT", "NU")
contig_stations <- station_info[!station_info$state %in% non_contig, ]

march_2024_data <- daily_weather |> dplyr:::filter(LST_DATE >= "2024-03-01", LST_DATE < "2024-04-01", !state %in% non_contig) |> dplyr:::group_by(`station name`, LONGITUDE, LATITUDE) |> dplyr:::summarise(avg_temp = mean(T_DAILY_AVG))

colmap <- colorRampPalette(c("#00007F", "blue", "#007FFF", "cyan", "#7FFF7F", "yellow", "#FF7F00", "red", "#7F0000"))

maps::map("usa")
points(march_2024_data$LONGITUDE, march_2024_data$LATITUDE, pch = 16, col =  colmap(10)[cut(march_2024_data$avg_temp, 10)])
legend(x = -72, y = 40, title="Temperature", legend = levels(cut(march_2024_data$avg_temp, 10)), col = colmap(10), pch=20, xpd=TRUE)
title("Average Temperature (°C) in March 2024")

grid <- create_grid(resolution_X = 100, resolution_Y=100)
interp_data = interpolate_data(march_2024_data$avg_temp, march_2024_data$LONGITUDE, march_2024_data$LATITUDE, gridpoints = grid, use_elev = F)
plot_interpolations(interp_data)
title("Average Interpolated Temperature (°C) in March 2024")

## -----------------------------------------------------------------------------
graphics.off()
num_stations <- nrow(contig_stations)
stations_high_day <- rep(NA, times = num_stations)
stations_low_day <- rep(NA, times = num_stations)

i <- 1
for (station_id in contig_stations$WBANNO){
  yearly_estimates = get_yearly_cycle(station_id)
  min_row <- which.min(yearly_estimates$avg_temp)
  max_row <- which.max(yearly_estimates$avg_temp)
  stations_high_day[i] <- yearly_estimates[max_row, "day_of_year"]
  stations_low_day[i] <- yearly_estimates[min_row, "day_of_year"]
  i <- i + 1
}

colmap <- colorRampPalette(c("#00007F", "blue", "#007FFF", "cyan", "#7FFF7F", "yellow", "#FF7F00", "red", "#7F0000"))
days_from_jan1 <- ifelse(stations_low_day > 100, stations_low_day - 365, stations_low_day)

maps::map("usa")
points(contig_stations$LONGITUDE, contig_stations$LATITUDE, pch = 16, col =  colmap(10)[cut(stations_high_day, 10)])
legend(x = -72, y = 40, title="Day of The Year",legend= levels(cut(stations_high_day, 10)), col = colmap(10), pch=20, xpd=TRUE)
title("Warmest Day of the Year")

maps::map("usa")
points(contig_stations$LONGITUDE, contig_stations$LATITUDE, pch = 16, col =  colmap(10)[cut(days_from_jan1, 10)])
legend(x = -74, y = 40, title="Days From Jan 1st",legend = levels(cut(days_from_jan1, 10)), col = colmap(10), pch=20, xpd=TRUE)
title("Coldest Day of the Year")

high_day_interp_data <- interpolate_data(stations_high_day, contig_stations$LONGITUDE, contig_stations$LATITUDE, gridpoints = grid)
plot_interpolations(high_day_interp_data)
title("Interpolated Warmest Day of the Year")

low_day_interp_data <- interpolate_data(days_from_jan1, contig_stations$LONGITUDE, contig_stations$LATITUDE, gridpoints = grid)
plot_interpolations(low_day_interp_data)
title("Interpolated Coldest Day of the Year from Jan 1st")

## -----------------------------------------------------------------------------
graphics.off()
diverse_stations_ids <- sort(c(63828, 94060, 4994, 64758, 53152, 94092, 53968, 94645, 54808, 4223))
diverse_stations <- station_info[station_info$WBANNO %in% diverse_stations_ids, ]

yearly_cycles <- rep(NA, times = 10)

par(mar = c(4, 5, 3, 12), xpd = TRUE)
plot(NULL, NULL, xlab="Day of the Year", ylab="Expected Temperature (°C)", xlim=c(1, 365), ylim=c(-20, 30))
i <- 1
for (station_id in diverse_stations$WBANNO){
  yearly_cycle <- get_yearly_cycle(station_id)
  points(x = yearly_cycle$day_of_year, y = yearly_cycle$avg_temp, type = "l", col = rainbow(10)[i], lwd = 2, lty = i)
  i = i + 1
}
par(cex = 0.8)
legend(x ="right", inset = c(-0.5, 0), title="Station", legend = diverse_stations$`station name`, col = rainbow(10), lty = 1:10, pch=20)

## -----------------------------------------------------------------------------
graphics.off()
trend_coefs <- rep(NA, length = nrow(contig_stations))
standard_errors <- rep(NA, length = nrow(contig_stations))
is_sig <- rep(F, length = nrow(contig_stations))
i <- 1
for (station_id in contig_stations$WBANNO){
    station_trend = temperature_trend(station_id)
    trend_coefs[i] = station_trend$coefficients["years_elapsed", "Estimate"]
    standard_errors[i] = station_trend$coefficients["years_elapsed", "Std. Error"]
    is_sig[i] = station_trend$coefficients["years_elapsed", "Pr(>|t|)"] <= 0.05
    i = i + 1
}

maps::map("usa")
points(contig_stations$LONGITUDE, contig_stations$LATITUDE, pch = 16 + is_sig, col =  colmap(10)[cut(trend_coefs, 10)])
legend(x = -74, y = 40, title="°C/yr Trend",legend = levels(cut(trend_coefs, 10)), col = colmap(10), pch=20, xpd=TRUE)
legend(x = -130, y = 30, title="Significance",legend = c("Not Significant", "Significant"), col = "black", pch= c(16, 17),  xpd=TRUE)
title("Temperature Trends in °C per Year")

low_se_indices = order(standard_errors)[1:as.integer(length(standard_errors) * 2/3)]

trend_interp_data <- interpolate_data(trend_coefs[low_se_indices], contig_stations$LONGITUDE[low_se_indices], contig_stations$LATITUDE[low_se_indices], gridpoints = grid)
plot_interpolations(trend_interp_data)
title("Interpolated Temperature Trends in °C per Year")

## -----------------------------------------------------------------------------
# according to https://www.weather.gov/media/slc/ClimateBook/Annual%20Average%20Temperature%20By%20Year.pdf
# the National Weather Service
years = 2004:2023
last_20_avg_F <-
  c(
    52.1,
    53.4,
    53.8,
    53.8,
    51.9,
    52.1,
    52.7,
    51.8,
    56.6,
    53.3,
    55.6,
    56.3,
    56.2,
    56.1,
    56.2,
    53.6,
    55.7,
    56.3,
    55.9,
    55.6
  )
last_20_avg_C <- (last_20_avg_F - 32) / 1.8
gov_cycle_lm <- lm(last_20_avg_C ~
                 years)
data_avg_change <- round(mean(trend_coefs[low_se_indices]), 2)
gov_avg_change <- round(summary(gov_cycle_lm)$coefficients["years", "Estimate"], 2)
print(paste("Weather data average trend:", data_avg_change))
print(paste("Government data average trend:", gov_avg_change))

