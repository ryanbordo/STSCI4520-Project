library(testthat)
library(USweather)

test_check("USweather")
